Name: Michael Pultorak
ID: 109415599

Structure of program:
---------------------
File organization: main.cpp, Car.cpp, Car.h, Carwash.cpp, Carwash.h
Functional organization: main creates a carwash object then reads in arrival times into a queue of Car objects. Main then calls start_simulation() which simulates the carwash. Finally, main calls write_output(), which displays results.

Status: It works completely.

Hardware & Platform I used: M1-Pro chip, 16 gb of ram, and mac os.

Compile: extract the archive and from a shell and run "make" This will create an executable "runexe" Then run ./runexe
